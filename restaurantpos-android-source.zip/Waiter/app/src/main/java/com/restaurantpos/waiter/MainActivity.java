package com.restaurantpos.waiter;
import android.app.*;import android.os.*;import android.content.*;import android.webkit.*;import android.widget.*;import android.graphics.Color;
public class MainActivity extends Activity {
 WebView web; android.content.SharedPreferences prefs; final String route="/waiter";
 @Override public void onCreate(Bundle b) {super.onCreate(b);prefs=getSharedPreferences("lan",MODE_PRIVATE);open();}
 void open() { LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);layout.setBackgroundColor(Color.WHITE);
 LinearLayout bar=new LinearLayout(this);EditText address=new EditText(this);address.setSingleLine(true);address.setText(prefs.getString("host","192.168.1.105"));address.setHint("Windows PC IP");bar.addView(address,new LinearLayout.LayoutParams(0,130,1));Button connect=new Button(this);connect.setText("Connect");bar.addView(connect);layout.addView(bar);
 web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);web.setWebViewClient(new WebViewClient());layout.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);
 connect.setOnClickListener(v->{String ip=address.getText().toString().trim();if(!ip.matches("[a-zA-Z0-9.:-]+")){Toast.makeText(this,"Enter PC IP only",Toast.LENGTH_LONG).show();return;}prefs.edit().putString("host",ip).apply();load(ip);});load(address.getText().toString().trim());}
 void load(String ip){web.loadUrl("http://"+ip+":4310"+route);}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
