@echo off
cd /d "%~dp0"
where gradle >nul 2>nul
if errorlevel 1 (echo Install Android Studio and Gradle or open this folder in Android Studio. & pause & exit /b 1)
gradle assembleDebug
if errorlevel 1 (echo BUILD FAILED & pause & exit /b 1)
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
