package com.restaurantpos.kitchen;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import java.net.*;
import java.nio.charset.StandardCharsets;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity {
  private WebView web;
  private SharedPreferences prefs;
  private TextToSpeech speech;
  private boolean speechReady = false;
  private final String route = "/kitchen";

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    prefs = getSharedPreferences("lan", MODE_PRIVATE);
    speech = new TextToSpeech(this, status -> {
      if (status == TextToSpeech.SUCCESS) {
        speechReady = speech.setLanguage(Locale.ENGLISH) >= 0;
      }
    });
    open();
  }

  private void open() {
    LinearLayout layout = new LinearLayout(this);
    layout.setOrientation(LinearLayout.VERTICAL);
    layout.setBackgroundColor(Color.WHITE);
    LinearLayout bar = new LinearLayout(this);
    EditText address = new EditText(this);
    address.setSingleLine(true);
    address.setText(prefs.getString("host", ""));
    address.setHint("Windows PC IP");
    bar.addView(address, new LinearLayout.LayoutParams(0, 130, 1));
    Button connect = new Button(this);
    connect.setText("Connect");
    bar.addView(connect);
    layout.addView(bar);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
    web.addJavascriptInterface(new KotVoiceBridge(), "KitchenVoice");
    web.setWebViewClient(new WebViewClient());
    layout.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
    setContentView(layout);
    connect.setOnClickListener(v -> {
      String ip = address.getText().toString().trim();
      if (!ip.matches("[a-zA-Z0-9.:-]+")) {
        Toast.makeText(this, "Enter PC IP only", Toast.LENGTH_LONG).show();
        return;
      }
      prefs.edit().putString("host", ip).apply();
      load(ip);
    });
    if(!address.getText().toString().trim().isEmpty()) load(address.getText().toString().trim());
    discover(address);
  }

  public class KotVoiceBridge {
    @JavascriptInterface public void announceNewKot() {
      runOnUiThread(() -> {
        if (speechReady && speech != null) {
          speech.speak("New KOT order received", TextToSpeech.QUEUE_FLUSH, null, "new-kot");
        }
      });
    }
  }

    private void discover(EditText address) {
    Toast.makeText(this,"Searching for TableFlow POS on Wi-Fi...",Toast.LENGTH_SHORT).show();
    new Thread(() -> {
      try (DatagramSocket sock = new DatagramSocket()) {
        sock.setBroadcast(true); sock.setSoTimeout(2500);
        byte[] query="TABLEFLOW_DISCOVER_V1".getBytes(StandardCharsets.US_ASCII);
        DatagramPacket request=new DatagramPacket(query,query.length,InetAddress.getByName("255.255.255.255"),4311);
        for(int attempt=0;attempt<3;attempt++) {
          sock.send(request);
          byte[] buffer=new byte[256]; DatagramPacket reply=new DatagramPacket(buffer,buffer.length);
          try {
            sock.receive(reply);
            String result=new String(reply.getData(),0,reply.getLength(),StandardCharsets.US_ASCII);
            if(!result.equals("TABLEFLOW_POS_V1:4310"))continue;
            String host=reply.getAddress().getHostAddress();
            runOnUiThread(() -> {address.setText(host);prefs.edit().putString("host",host).apply();load(host);});
            return;
          }catch(SocketTimeoutException ignored){}
        }
        runOnUiThread(() -> Toast.makeText(this,"POS not found. Enter the Windows PC IP manually. Check firewall UDP 4311.",Toast.LENGTH_LONG).show());
      } catch(Exception e) {runOnUiThread(() -> Toast.makeText(this,"Discovery unavailable: "+e.getMessage(),Toast.LENGTH_LONG).show());}
    }).start();
  }

private void load(String ip) { web.loadUrl("http://" + ip + ":4310" + route); }
  @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
  @Override protected void onDestroy() {
    if (web != null) { web.removeJavascriptInterface("KitchenVoice"); web.destroy(); }
    if (speech != null) { speech.stop(); speech.shutdown(); }
    super.onDestroy();
  }
}
