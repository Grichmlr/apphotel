package com.restaurantpos.kitchen;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity {
  private WebView web;
  private SharedPreferences prefs;
  private TextToSpeech speech;
  private boolean speechReady = false;
  private final String route = "/kitchen";

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    prefs = getSharedPreferences("lan", MODE_PRIVATE);
    speech = new TextToSpeech(this, status -> {
      if (status == TextToSpeech.SUCCESS) {
        speechReady = speech.setLanguage(Locale.ENGLISH) >= 0;
      }
    });
    open();
  }

  private void open() {
    LinearLayout layout = new LinearLayout(this);
    layout.setOrientation(LinearLayout.VERTICAL);
    layout.setBackgroundColor(Color.WHITE);
    LinearLayout bar = new LinearLayout(this);
    EditText address = new EditText(this);
    address.setSingleLine(true);
    address.setText(prefs.getString("host", "192.168.1.105"));
    address.setHint("Windows PC IP");
    bar.addView(address, new LinearLayout.LayoutParams(0, 130, 1));
    Button connect = new Button(this);
    connect.setText("Connect");
    bar.addView(connect);
    layout.addView(bar);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
    web.addJavascriptInterface(new KotVoiceBridge(), "KitchenVoice");
    web.setWebViewClient(new WebViewClient());
    layout.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
    setContentView(layout);
    connect.setOnClickListener(v -> {
      String ip = address.getText().toString().trim();
      if (!ip.matches("[a-zA-Z0-9.:-]+")) {
        Toast.makeText(this, "Enter PC IP only", Toast.LENGTH_LONG).show();
        return;
      }
      prefs.edit().putString("host", ip).apply();
      load(ip);
    });
    load(address.getText().toString().trim());
  }

  public class KotVoiceBridge {
    @JavascriptInterface public void announceNewKot() {
      runOnUiThread(() -> {
        if (speechReady && speech != null) {
          speech.speak("New KOT order received", TextToSpeech.QUEUE_FLUSH, null, "new-kot");
        }
      });
    }
  }

  private void load(String ip) { web.loadUrl("http://" + ip + ":4310" + route); }
  @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
  @Override protected void onDestroy() {
    if (web != null) { web.removeJavascriptInterface("KitchenVoice"); web.destroy(); }
    if (speech != null) { speech.stop(); speech.shutdown(); }
    super.onDestroy();
  }
}
