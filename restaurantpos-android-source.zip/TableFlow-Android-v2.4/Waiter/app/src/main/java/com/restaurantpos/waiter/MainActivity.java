package com.restaurantpos.waiter;
import android.app.*;import android.os.*;import android.content.*;import android.webkit.*;import android.widget.*;import android.graphics.Color;
import java.net.*;
import java.nio.charset.StandardCharsets;
public class MainActivity extends Activity {
 WebView web; android.content.SharedPreferences prefs; final String route="/waiter";
 @Override public void onCreate(Bundle b) {super.onCreate(b);prefs=getSharedPreferences("lan",MODE_PRIVATE);open();}
 void open() { LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);layout.setBackgroundColor(Color.WHITE);
 LinearLayout bar=new LinearLayout(this);EditText address=new EditText(this);address.setSingleLine(true);address.setText(prefs.getString("host","192.168.1.105"));address.setHint("Windows PC IP");bar.addView(address,new LinearLayout.LayoutParams(0,130,1));Button connect=new Button(this);connect.setText("Connect");bar.addView(connect);layout.addView(bar);
 web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);web.setWebViewClient(new WebViewClient());layout.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);
 connect.setOnClickListener(v->{String ip=address.getText().toString().trim();if(!ip.matches("[a-zA-Z0-9.:-]+")){Toast.makeText(this,"Enter PC IP only",Toast.LENGTH_LONG).show();return;}prefs.edit().putString("host",ip).apply();load(ip);});if(!address.getText().toString().trim().isEmpty()) load(address.getText().toString().trim());
    discover(address);}
   private void discover(EditText address) {
    Toast.makeText(this,"Searching for TableFlow POS on Wi-Fi...",Toast.LENGTH_SHORT).show();
    new Thread(() -> {
      try (DatagramSocket sock = new DatagramSocket()) {
        sock.setBroadcast(true); sock.setSoTimeout(2500);
        byte[] query="TABLEFLOW_DISCOVER_V1".getBytes(StandardCharsets.US_ASCII);
        DatagramPacket request=new DatagramPacket(query,query.length,InetAddress.getByName("255.255.255.255"),4311);
        for(int attempt=0;attempt<3;attempt++) {
          sock.send(request);
          byte[] buffer=new byte[256]; DatagramPacket reply=new DatagramPacket(buffer,buffer.length);
          try {
            sock.receive(reply);
            String result=new String(reply.getData(),0,reply.getLength(),StandardCharsets.US_ASCII);
            if(!result.equals("TABLEFLOW_POS_V1:4310"))continue;
            String host=reply.getAddress().getHostAddress();
            runOnUiThread(() -> {address.setText(host);prefs.edit().putString("host",host).apply();load(host);});
            return;
          }catch(SocketTimeoutException ignored){}
        }
        runOnUiThread(() -> Toast.makeText(this,"POS not found. Enter the Windows PC IP manually. Check firewall UDP 4311.",Toast.LENGTH_LONG).show());
      } catch(Exception e) {runOnUiThread(() -> Toast.makeText(this,"Discovery unavailable: "+e.getMessage(),Toast.LENGTH_LONG).show());}
    }).start();
  }

void load(String ip){web.loadUrl("http://"+ip+":4310"+route);}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
