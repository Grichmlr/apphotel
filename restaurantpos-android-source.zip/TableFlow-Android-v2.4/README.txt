RESTAURANTPOS - TWO SEPARATE ANDROID APPS (SOURCE PROJECTS)

IMPORTANT: This ZIP contains Android Studio projects, not compiled APKs.

The provided RestaurantPOS Windows v1 already includes /waiter and /kitchen routes on its built-in LAN server (port 4310). These Android apps are separate WebView launchers for those existing screens, sharing the Windows database. They do NOT create a second database.

SETUP
1. Start RestaurantPOS.exe on Windows and complete manager setup.
2. Windows PC and Android devices must connect to the same Wi-Fi network.
3. In Windows RestaurantPOS > Wi-Fi device addresses, find PC IP. Allow Windows Firewall private network access for TCP 4310.
4. On Windows PC, create staff users with waiter and kitchen roles; assign local passwords.
5. Open Waiter and Kitchen folders separately in Android Studio (with Android SDK installed). Build > Build APK(s). Alternatively run BUILD-APK.bat if Gradle is on PATH.
6. Install each debug APK on the corresponding Android phone. Enter PC IP on first screen and tap Connect.
7. Log in with that staff role. Orders and status changes use the existing RestaurantPOS backend.

TEST BEFORE USE: verify phone can reach http://PC_IP:4310/waiter and /kitchen, login, place order, KOT arrival, ready state and billing sync.

SECURITY: HTTP traffic is not encrypted; use only trusted, isolated restaurant Wi-Fi. Do not port-forward 4310. These wrappers require the Windows PC to remain running. For production consider TLS and a maintained Android target SDK.

APK output after build: app/build/outputs/apk/debug/app-debug.apk (separate in each project).
