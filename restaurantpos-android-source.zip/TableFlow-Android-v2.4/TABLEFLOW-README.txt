TableFlow Waiter + Kitchen Android source. Run BUILD-APK.bat in each project. Existing application IDs retained to preserve compatibility. This package does not contain built APKs.
